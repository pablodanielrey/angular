Converse.js API
===============

Done:
-----

* initialize 

TBD:
----

* log in
* log out
* open a chat box
* close a chat box
* toggle a chat box
* change user's presence status
* change user's custom message
