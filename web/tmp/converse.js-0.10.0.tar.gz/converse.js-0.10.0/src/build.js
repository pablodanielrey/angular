({
    baseUrl: "../",
    name: "components/almond/almond.js",
    out: "../builds/converse.min.js",
    include: ['main'],
    mainConfigFile: '../main.js',
    paths: {
        "converse-dependencies":    "src/deps-full"
    }
})
