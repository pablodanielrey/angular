/*global jQuery */
define('jquery', [], function () {
    return jQuery;
});
